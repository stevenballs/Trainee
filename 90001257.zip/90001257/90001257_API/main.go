package main

import (
	"customer/controller"
	_ "customer/docs"

	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
)

// @title Swagger Example Golang API
// @version 1.1
// @description This is a sample go lang api. \n\n **Update 1.1** \n\t - *ตัวอย่าง Authen* \n\t - *call แบบ RawSQL*
// @termsOfService http://swagger.io/terms/

// @license.name Apache 2.0
// @license.url http://www.apache.org/licenses/LICENSE-2.0.html

// @host localhost:8086
// @BasePath /api/v1

func main() {
	r := gin.Default()
	r.Use(cors.Default())

	v1 := r.Group("api/v1")
	{
		br := controller.NewCustomerController()
		c := v1.Group("/customer")
		{
			c.GET(":Id", br.ReadCustomer)
			c.GET("", br.ReadAllCustomer)
			c.POST("", br.CreateCustomer)
			c.PUT("", br.UpdateCustomer)
			c.DELETE(":id", br.DeleteCustomer)
		}

	}
	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))
	r.Run(":8086")
}
