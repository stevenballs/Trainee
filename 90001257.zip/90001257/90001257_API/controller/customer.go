package controller

import (
	"customer/handler"
	"customer/model"
	"customer/repository"
	"errors"
	"net/http"

	"github.com/gin-gonic/gin"
)

type CustomerController struct{}

func NewCustomerController() *CustomerController {
	return &CustomerController{}
}

// Select Customer godoc
// @Summary ลุกค้า
// @Description Get Customer Data
// @Tags Customer
// @Accept  json
// @Produce  json
// @Param id path string true "id"
// @Success 200 {object} model.Controller
// @Failure 400 {object} handler.HTTPError
// @Failure 404 {object} handler.HTTPError
// @Failure 500 {object} handler.HTTPError
// @Router /customer/{id} [get]
func (c *CustomerController) ReadCustomer(ctx *gin.Context) {
	Id := ctx.Param("Id")
	if Id == "undefined" {
		Id = ""
	}
	CustomerConfig := repository.CustomerRepository{}

	if result, err := CustomerConfig.ReadCustomer(Id); err != nil {
		handler.NewError(ctx, http.StatusNotFound, err)
		return
	} else {
		ctx.JSON(http.StatusOK, model.Controller{
			Message: "successful",
			Data:    result,
		})
	}
}

// Select Customer godoc
// @Summary ลุกค้า
// @Description Get Customer Data
// @Tags Customer
// @Accept  json
// @Produce  json
// @Success 200 {object} model.Controller
// @Failure 400 {object} handler.HTTPError
// @Failure 404 {object} handler.HTTPError
// @Failure 500 {object} handler.HTTPError
// @Router /customer [get]
func (c *CustomerController) ReadAllCustomer(ctx *gin.Context) {
	CustomerConfig := repository.CustomerRepository{}

	if result, err := CustomerConfig.ReadAllCustomer(); err != nil {
		handler.NewError(ctx, http.StatusNotFound, err)
		return
	} else {
		ctx.JSON(http.StatusOK, model.Controller{
			Message: "successful",
			Data:    result,
		})
	}
}

// Create Customer godoc
// @Summary สร้าง ลุกค้า
// @Description Create Customer
// @Tags Customer
// @Accept  json
// @Produce  json
// @Param account body model.CustomerModel true "Model Customer"
// @Success 200 {object} model.Controller
// @Failure 400 {object} handler.HTTPError
// @Failure 404 {object} handler.HTTPError
// @Failure 500 {object} handler.HTTPError
// @Router /customer [post]
func (c *CustomerController) CreateCustomer(ctx *gin.Context) {
	var CustomerData model.CustomerModel
	if err := ctx.ShouldBindJSON(&CustomerData); err != nil {
		handler.NewError(ctx, http.StatusBadRequest, err)
		return
	}
	CustomerConfig := repository.CustomerRepository{}

	if err := CustomerConfig.CreateCustomer(CustomerData); err != nil {
		handler.NewError(ctx, http.StatusBadRequest, err)
		return
	} else {
		ctx.JSON(http.StatusOK, model.Controller{Message: "successful", Data: nil})
	}
}

// Update Customer godoc
// @Summary แก้ไข ลุกค้า
// @Description Adjust Customer
// @Tags Customer
// @Accept  json
// @Produce  json
// @Param account body model.CustomerModel true "Model Customer"
// @Success 200 {object} model.Controller
// @Failure 400 {object} handler.HTTPError
// @Failure 404 {object} handler.HTTPError
// @Failure 500 {object} handler.HTTPError
// @Router /customer [put]
func (c *CustomerController) UpdateCustomer(ctx *gin.Context) {
	var updateCustomer model.CustomerModel
	if err := ctx.ShouldBindJSON(&updateCustomer); err != nil {
		handler.NewError(ctx, http.StatusBadRequest, err)
		return
	}

	CustomerConfig := repository.CustomerRepository{}

	if err := CustomerConfig.UpdateCustomer(updateCustomer); err != nil {
		handler.NewError(ctx, http.StatusNotFound, err)
		return
	} else {
		ctx.JSON(http.StatusOK, model.Controller{
			Message: "successful",
			Data:    model.QueryEffected{Row: int64(updateCustomer.Id)},
		})
	}
}

// Delete Customer godoc
// @Summary ลบ ลุกค้า
// @Description Delete Customer
// @Tags Customer
// @Accept  json
// @Produce  json
// @Param  id path string true "any id"
// @Success 200 {object} model.Controller
// @Failure 400 {object} handler.HTTPError
// @Failure 404 {object} handler.HTTPError
// @Failure 500 {object} handler.HTTPError
// @Router /customer/{id} [delete]
func (c *CustomerController) DeleteCustomer(ctx *gin.Context) {
	idStr := ctx.Param("id")
	if idStr == "" {
		handler.NewError(ctx, http.StatusBadRequest, errors.New("id is undefine"))
	}
	CustomerConfig := repository.CustomerRepository{}

	if err := CustomerConfig.DeleteCustomer(idStr); err != nil {
		handler.NewError(ctx, http.StatusNotFound, err)
		return
	} else {
		ctx.JSON(http.StatusOK, model.Controller{
			Message: "successful",
			Data:    idStr,
		})
	}

}
