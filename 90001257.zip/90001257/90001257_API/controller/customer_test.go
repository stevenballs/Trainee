package controller_test

import (
	"testing"
)

func TestReadCustomer(t *testing.T) {
}

func TestReadAllCustomer(t *testing.T) {

}

func TestCreateCustomer(t *testing.T) {

}

func TestUpdateCustomer(t *testing.T) {

}

func TestDeleteCustomer(t *testing.T) {

}
