How to run my project by open Visual Code Studio.
1. click 'Terminal' > New Terminal
2. open main.go page.
3. run application by 'F5 button'.