package model

type Controller struct {
	Message string      `json:"message" example:"success"`
	Data    interface{} `json:"data"`
}

type QueryEffected struct {
	Row int64 `json:"row" example:"1"`
}
