package model

type CustomerModel struct {
	Id         int    `db:"Id" json:"Id"`
	CustomerId string `db:"CustomerId" json:"CustomerId"`
	FirstName  string `db:"FirstName" json:"FirstName"`
	LastName   string `db:"LastName" json:"LastName"`
}
