package model

import (
	"log"

	"github.com/spf13/viper"
)

type SystemConfig struct {
	ConnectString string
	Host          string
	Protocal      string
}

func (c *SystemConfig) LoadConfig() {
	viper.SetConfigFile(".env")
	err := viper.ReadInConfig()
	if err != nil {
		log.Fatalf("Error while reading config file %s", err)
	}
	c.ConnectString = viper.GetString("CONNECTION_STRING")
	c.Host = viper.GetString("HOST")
	c.Protocal = viper.GetString("PROTOCAL")
}
