USE [HOMEWORK]
GO

/****** Object:  Table [dbo].[TB_Customer]    Script Date: 23-Nov-21 3:48:11 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[TB_Customer](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [nvarchar](4) NULL,
	[FirstName] [nvarchar](80) NULL,
	[LastName] [nvarchar](80) NULL,
	[Delflag] [int] NULL,
 CONSTRAINT [PK_TB_Customer] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[TB_Customer] ADD  CONSTRAINT [DF_TB_Customer_Delflag]  DEFAULT ((0)) FOR [Delflag]
GO


