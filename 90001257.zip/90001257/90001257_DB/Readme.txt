How to set Database.
1.open file on sql server magement studio.
2.excute script.