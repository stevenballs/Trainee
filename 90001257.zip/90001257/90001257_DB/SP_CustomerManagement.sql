USE [HOMEWORK]
GO

/****** Object:  StoredProcedure [dbo].[SP_CustomerManagement]    Script Date: 23-Nov-21 3:46:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Jakkapong Subinwong
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SP_CustomerManagement]
	@Process NVARCHAR(30) = NULL,
	@Id INT = -1,
	@CustomerId NVARCHAR(4) = NULL,
	@FirstName NVARCHAR(80) = NULL,
	@LastName NVARCHAR(80) = NULL
AS
BEGIN
	IF @Process = 'CREATE' 
		BEGIN
			DECLARE @IdTemp nvarchar(4)
			DECLARE @IsCustomerId NVARCHAR(30) = (SELECT TOP 1 Id FROM TB_Customer ORDER BY Id DESC)
			IF (@IsCustomerId IS NULL) BEGIN
				SET @IdTemp = (SELECT TOP 1  right('0000' + convert(varchar(10), CONVERT(INT,RIGHT('0000',4))+1), 4))
			END
			ELSE 
			BEGIN
				SET @IdTemp = (SELECT TOP 1  right('0000' + convert(varchar(10), CONVERT(INT,RIGHT(Id,4))+1), 4) FROM TB_Customer ORDER BY Id DESC)	
			END
			INSERT INTO TB_Customer(CustomerId, FirstName, LastName)
			VALUES (@IdTemp, @FirstName, @LastName)
		END
	ELSE IF @Process = 'UPDATE'
		BEGIN
			UPDATE TB_Customer
			SET FirstName = @FirstName,
				LastName = @LastName
			WHERE Id = @Id
		END
	ELSE IF @Process = 'DELETE'
		BEGIN
			UPDATE TB_Customer
			SET Delflag = 1
			WHERE Id = @Id
		END
	ELSE IF @Process = 'FIND'
		BEGIN
			SELECT  c.Id,
					c.CustomerId,
					c.FirstName,
					c.LastName
			FROM TB_Customer c
			WHERE Id = @Id
			AND Delflag = 0
		END
	ELSE 
		BEGIN
			SELECT  c.Id,
					c.CustomerId,
					c.FirstName,
					c.LastName
			FROM TB_Customer c
			WHERE Delflag = 0
		END
END
GO


