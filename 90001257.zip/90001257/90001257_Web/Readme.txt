How to run my project by open Visual Code Studio.
1. click 'Terminal' > New Terminal
2. write command 'npm i'
3. run application by write command 'ng serve' in Terminal frame.
4 defualt url is localhost:4200 copy and open in browser