# Shop Book

### Code Analysis
Sonarqube ล่าสุด
![Sonarqube Result](/document/images/sonarqube_result.png "Sonarqube")

### Code Smell
ไฟล์ default ที่ angular generate มาให้เอง กับ ส่วนของ 3rd Party Package ครับ
