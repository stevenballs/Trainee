import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { CustomerService } from 'src/app/service/customer.service';

import { AlertDialogComponent } from 'src/app/components/alert-dialog/alert-dialog.component';
import { CustomerDialogComponent } from 'src/app/components/customer-dialog/customer-dialog.component';
import { ConfirmDialogComponent } from 'src/app/components/confirm-dialog/confirm-dialog.component';
import { Customer } from 'src/app/models/customer';
import { Paging } from 'src/app/models/paging';
//import * as moment from 'moment';
@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.scss']
})
export class CustomerListComponent implements OnInit {

  page: Paging = {
    size: 5,
    totalElements: 0,
    totalPages: 0,
    pageNumber: 0
  };

  keyword = '';
  rows = [];
columns = [
    { name: 'CustomerId', prop: 'CustomerId' },
    { name: 'FirstName', prop: 'FirstName' },
    { name: 'LastName', prop: 'LastName' }];
  
    title: string = 'ลูกค้า'
  
  constructor(private dialog: MatDialog, private CustomerServce: CustomerService) { }

  ngOnInit(): void {
    this.getData();
  }

  showDeleteDialog(row: Customer): void {
    /*get value form dialog */
    const confirmRef = this.dialog.open(ConfirmDialogComponent, { data: { dataAttach: row } });
    /* save data to api */
    confirmRef.componentInstance.OnSubmit.subscribe((isSubmit: boolean) => {

      if (isSubmit) {
        this.CustomerServce.deleteCustomer(row.Id)
          .subscribe(() => {
            this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: 'ทำรายการสำเร็จ' } });
            this.getData();
          },
          ({ error: { message } }) =>
              this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: message } })
          );
      }
    });
  }

  showEditDialog(row: Customer): void {
    const confirmRef = this.dialog.open(CustomerDialogComponent, { data: { mode: 'EDIT', dataAttach: row },width: '800px' });
    confirmRef.componentInstance.OnSubmit.subscribe((dataCallBack: Customer) => {
      if (dataCallBack) {
        this.CustomerServce.editCustomer(dataCallBack).subscribe(() => {
          this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: 'ทำรายการสำเร็จ' } });
          this.getData();
        },
        ({ error: { message } }) => {
          this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: message } });
        });
      }
    });
  }

  submitRow(row: Customer): void {
    this.CustomerServce.editCustomer(row).subscribe(() => {
      this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: 'ทำรายการสำเร็จ' } });
      this.getData();
    },
    ({ error: { message } }) => {
      this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: message } });
    });
  }
  
  showCreateDialog(type: string, row: Customer): void {
    let confirmRef;
    if (type == 'NEW') {
      confirmRef = this.dialog.open(CustomerDialogComponent, { data: { mode: 'NEW', dataAttach: row },width: '800px' });
      confirmRef.componentInstance.OnSubmit.subscribe((dataCallBack: Customer) => {
        if (dataCallBack) {
          this.CustomerServce.createCustomer(dataCallBack).subscribe(() => {
            this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: 'ทำรายการสำเร็จ' } });
            this.getData();
          },
          ({ error: { message } }) => {
            this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: message } });
          });
        }
      });
    } else {
      confirmRef = this.dialog.open(CustomerDialogComponent, { data: { mode: type, dataAttach: row }, width: '800px' });
      confirmRef.componentInstance.OnSubmit.subscribe((dataCallBack: Customer) => {
        if (dataCallBack) {
          this.CustomerServce.editCustomer(row).subscribe(() => {
            this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: 'ทำรายการสำเร็จ' } });
            this.getData();
            row.isEdit = false;
          },
            ({ error: { message } }) => {
              this.dialog.open(AlertDialogComponent, { width: '500px', data: { title: this.title, content: message } });
            });
        }
      });
    }

  }

  getData(Id?: string): void {
    this.CustomerServce.getCustomer(Id).subscribe(res => {
      if (res.data) {
        this.rows = res.data;
        this.page.pageNumber = 0;
        this.page.totalElements = this.rows.length;
        this.page.totalPages = this.rows.length / 5;
      } else {
        this.page.pageNumber = 0;
        this.page.totalElements = 0;
        this.page.totalPages = 0;
      }
    });
  }

}
