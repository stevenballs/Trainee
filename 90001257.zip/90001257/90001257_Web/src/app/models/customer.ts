export interface Customer {
  Id: number;
  CustomerId: string;
  FirstName: string;
  LastName: string;
  isEdit: boolean;
}