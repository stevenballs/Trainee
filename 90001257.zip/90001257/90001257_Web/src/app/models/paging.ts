export interface Paging {
  size: number;
  totalElements: number;
  totalPages: number;
  pageNumber: number;
}
