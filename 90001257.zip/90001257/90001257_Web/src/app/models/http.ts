interface HttpResult<T> {
  message: string;
  data: T;
}

export { HttpResult };
