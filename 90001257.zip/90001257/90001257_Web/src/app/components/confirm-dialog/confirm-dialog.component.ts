import { Component, EventEmitter, Inject, Output } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss']
})
export class ConfirmDialogComponent {
  @Output() OnSubmit = new EventEmitter<any>(true);
  constructor(@Inject(MAT_DIALOG_DATA) public data: any) {
  }

  submit(): void {
    this.OnSubmit.emit(true);
  }

  cancel(): void {
    this.OnSubmit.emit(false);
  }

}
