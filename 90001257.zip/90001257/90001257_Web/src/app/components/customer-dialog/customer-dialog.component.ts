import { Component, EventEmitter, Inject, OnInit, Output } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Customer } from 'src/app/models/customer';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer-dialog',
  templateUrl: './customer-dialog.component.html',
  styleUrls: ['./customer-dialog.component.scss']
})
export class CustomerDialogComponent implements OnInit {

  @Output() OnSubmit = new EventEmitter<any>(true);
  title = 'เพิ่มรายการ';
  customerForm: FormGroup;
  dataPayload: Customer;
  disabledControl: boolean = false;
  mode: string = '';
  dataAttach = {
    Id: -1,
    CustomerId: '',
    FirstName: '',
    LastName:'',
    isEdit: false
  };

  constructor(
    @Inject(MAT_DIALOG_DATA) data: { mode: string, dataAttach: Customer },
    dialogRef: MatDialogRef<CustomerDialogComponent>,
    private formBuilder: FormBuilder) {
    dialogRef.disableClose = true;
    this.mode = data.mode;
    if (data.mode === 'VIEW') {
      this.title = 'VIEW';
      this.dataPayload = data.dataAttach;
      this.disabledControl = true;
    }
    else if (data.mode === 'EDIT') {
      this.title = 'EDIT';
      this.dataPayload = data.dataAttach;
    } else {
      this.dataPayload = {
        Id: -1,
        CustomerId: '',
        FirstName: '',
        LastName:'',
        isEdit: false
      };
    }
  }

  ngOnInit(): void {
    this.customerForm = this.formBuilder.group({
      FirstName: ['', Validators.required],
      LastName: ['', Validators.required]
  });
  }

  submit(): void {
    this.OnSubmit.emit(this.dataPayload);
  }
  canSave() {
    let result = false;
    if (this.dataPayload.FirstName == '' || this.dataPayload.LastName == '') {
      result = true;
    }
    return result;
  }
 
  cancel(): void {
    this.OnSubmit.emit();
  }

}
